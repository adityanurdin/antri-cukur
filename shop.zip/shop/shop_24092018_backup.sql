-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2018 at 04:28 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shop`
--
CREATE DATABASE IF NOT EXISTS `shop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shop`;

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE IF NOT EXISTS `auth` (
  `auth_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`auth_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `auth`
--

INSERT INTO `auth` (`auth_id`, `email`, `password`) VALUES
(1, 'adityanurdin0@gmail.com', '39cf51637c7d61f1a96d8792d08a2689');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(25) NOT NULL,
  `tanggal_kategori` datetime NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `tanggal_kategori`) VALUES
(1, 'T-shirt', '0000-00-00 00:00:00'),
(2, 'Jeans', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE IF NOT EXISTS `produk` (
  `produk_id` int(25) NOT NULL AUTO_INCREMENT,
  `kategori_id` int(25) DEFAULT NULL,
  `nama_produk` varchar(25) NOT NULL,
  `harga_produk` int(25) NOT NULL,
  `ukuran_produk4` varchar(11) DEFAULT NULL,
  `ukuran_produk2` varchar(11) DEFAULT NULL,
  `ukuran_produk3` varchar(11) DEFAULT NULL,
  `ukuran_produk1` varchar(11) DEFAULT NULL,
  `jumlah_produk` int(25) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  `slug_produk` varchar(150) NOT NULL,
  `tanggal_produk` datetime NOT NULL,
  `foto_produk` varchar(100) NOT NULL,
  `foto_produk2` varchar(100) NOT NULL,
  `foto_produk3` varchar(100) NOT NULL,
  `status_produk` int(11) NOT NULL,
  PRIMARY KEY (`produk_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`produk_id`, `kategori_id`, `nama_produk`, `harga_produk`, `ukuran_produk4`, `ukuran_produk2`, `ukuran_produk3`, `ukuran_produk1`, `jumlah_produk`, `deskripsi_produk`, `slug_produk`, `tanggal_produk`, `foto_produk`, `foto_produk2`, `foto_produk3`, `status_produk`) VALUES
(1, 1, 'Setelan Kurta Delica', 190000, 'XL', 'M', 'L', 'S', 10, '<p>Description... Product</p>\r\n', 'setelan-kurta-delica', '2018-09-22 08:01:41', '', '', '', 0),
(2, 2, 'Mega Ripped Jeans', 250000, NULL, 'M', 'L', 'S', 50, '<p>Description... Product</p>\r\n', 'mega-ripped-jeans', '2018-09-22 08:03:17', '', '', '', 0),
(3, 2, 'Washed Skinny Jeans', 220000, NULL, 'M', 'L', 'S', 15, '<p>Description... Product</p>\r\n', 'washed-skinny-jeans', '2018-09-22 08:03:52', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_log`
--

CREATE TABLE IF NOT EXISTS `tabel_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_time` datetime DEFAULT NULL,
  `log_user` varchar(255) DEFAULT NULL,
  `log_tipe` int(11) DEFAULT NULL,
  `log_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tabel_log`
--

INSERT INTO `tabel_log` (`log_id`, `log_time`, `log_user`, `log_tipe`, `log_desc`) VALUES
(1, '2018-09-22 08:00:23', 'adityanurdin0@gmail.com', 0, 'Sign in'),
(2, '2018-09-22 08:00:55', 'adityanurdin0@gmail.com', 2, 'Create a category : <b>T-shirt</b>'),
(3, '2018-09-22 08:01:09', 'adityanurdin0@gmail.com', 2, 'Create a category : <b>Jeans</b>'),
(4, '2018-09-22 08:02:05', 'adityanurdin0@gmail.com', 2, 'Adding a product : <b>Setelan Kurta Delica</b>'),
(5, '2018-09-22 08:03:42', 'adityanurdin0@gmail.com', 2, 'Adding a product : <b>Mega Ripped Jeans</b> on  <b>2018-09-22 08:03:17</b>'),
(6, '2018-09-22 08:04:17', 'adityanurdin0@gmail.com', 2, 'Adding a product : <b>Washed Skinny Jeans</b> on  <b>2018-09-22 08:03:52</b>'),
(7, '2018-09-22 08:11:35', 'adityanurdin0@gmail.com', 2, 'Adding a product : <b>hapus</b>'),
(8, '2018-09-22 08:11:41', 'adityanurdin0@gmail.com', 3, 'Hide a product  : '),
(9, '2018-09-22 08:11:46', 'adityanurdin0@gmail.com', 4, 'Delete '),
(10, '2018-09-23 09:49:09', 'adityanurdin0@gmail.com', 0, 'Sign in'),
(11, '2018-09-23 09:56:23', 'adityanurdin0@gmail.com', 3, 'Hide a product  : '),
(12, '2018-09-23 09:56:36', 'adityanurdin0@gmail.com', 3, 'Unhide a product : '),
(13, '2018-09-23 10:08:38', 'adityanurdin0@gmail.com', 3, 'Hide a product  : '),
(14, '2018-09-23 10:08:56', 'adityanurdin0@gmail.com', 3, 'Unhide a product : '),
(15, '2018-09-23 10:11:39', 'adityanurdin0@gmail.com', 3, 'Hide a product  : '),
(16, '2018-09-23 10:11:56', 'adityanurdin0@gmail.com', 3, 'Unhide a product : '),
(17, '2018-09-23 10:12:42', 'adityanurdin0@gmail.com', 2, 'Adding a product : <b>hapus</b>'),
(18, '2018-09-23 10:12:43', 'adityanurdin0@gmail.com', 2, 'Adding a product : <b>hapus</b>'),
(19, '2018-09-23 10:12:59', 'adityanurdin0@gmail.com', 4, 'Delete '),
(20, '2018-09-23 10:13:04', 'adityanurdin0@gmail.com', 4, 'Delete ');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
