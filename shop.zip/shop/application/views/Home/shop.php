<div class="container-fluid">
<div class="row">
  <div class="col-sm-2">
  </div>
  <div class="col-sm-8">
    <br>
     <div class="w3-col l3 s6">
        <div class="w3-display-container">
          <img src="<?= base_url();?>/assets/images/foto_barang/kurta1.png" class="img-responsive" style="width:100%">
          <span class="w3-tag w3-display-topleft">SALE</span>
          <div class="w3-display-middle w3-display-hover">
            <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
          </div>
        </div>
        <p>Setelan Kurta Delica<br><b class="w3-text-red">Rp.190.000</b></p>
    </div>
    <div class="w3-col l3 s6">
       <div class="w3-display-container">
         <img src="<?= base_url();?>/assets/images/foto_barang/jeans2.jpg" class="img-responsive" style="width:100%">
         <span class="w3-tag w3-display-topleft">NEW</span>
         <div class="w3-display-middle w3-display-hover">
           <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
         </div>
       </div>
       <p>Mega Ripped Jeans<br><b class="w3-text-red">$19.99</b></p>
   </div>
   <div class="w3-col l3 s6">
      <div class="w3-display-container">
        <img src="<?= base_url();?>/assets/images/foto_barang/jeans3.jpg" class="img-responsive" style="width:100%">
        <span class="w3-tag w3-display-topleft"></span>
        <div class="w3-display-middle w3-display-hover">
          <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
        </div>
      </div>
      <p>Washed Skinny Jeans<br><b class="w3-text-red">$20.50</b></p>
  </div>
  <div class="w3-col l3 s6">
     <div class="w3-display-container">
       <img src="<?= base_url();?>/assets/images/foto_barang/jeans2.jpg" class="img-responsive" style="width:100%">
       <span class="w3-tag w3-display-topleft"></span>
       <div class="w3-display-middle w3-display-hover">
         <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
       </div>
     </div>
     <p>Washed Skinny Jeans<br><b class="w3-text-red">$20.50</b></p>
 </div>
 <div class="w3-col l3 s6">
    <div class="w3-display-container">
      <img src="<?= base_url();?>/assets/images/foto_barang/jeans1.jpg" class="img-responsive" style="width:100%">
      <span class="w3-tag w3-display-topleft"></span>
      <div class="w3-display-middle w3-display-hover">
        <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
      </div>
    </div>
    <p>Washed Skinny Jeans<br><b class="w3-text-red">$20.50</b></p>
</div>
<div class="w3-col l3 s6">
   <div class="w3-display-container">
     <img src="<?= base_url();?>/assets/images/foto_barang/jeans3.jpg" class="img-responsive" style="width:100%">
     <span class="w3-tag w3-display-topleft"></span>
     <div class="w3-display-middle w3-display-hover">
       <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
     </div>
   </div>
   <p>Washed Skinny Jeans<br><b class="w3-text-red">$20.50</b></p>
</div>
<div class="w3-col l3 s6">
   <div class="w3-display-container">
     <img src="<?= base_url();?>/assets/images/foto_barang/jeans2.jpg" class="img-responsive" style="width:100%">
     <span class="w3-tag w3-display-topleft"></span>
     <div class="w3-display-middle w3-display-hover">
       <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
     </div>
   </div>
   <p>Washed Skinny Jeans<br><b class="w3-text-red">$20.50</b></p>
</div>
<div class="w3-col l3 s6">
   <div class="w3-display-container">
     <img src="<?= base_url();?>/assets/images/foto_barang/jeans1.jpg" class="img-responsive" style="width:100%">
     <span class="w3-tag w3-display-topleft"></span>
     <div class="w3-display-middle w3-display-hover">
       <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
     </div>
   </div>
   <p>Washed Skinny Jeans<br><b class="w3-text-red">$20.50</b></p>
</div>



</div>
<div class="col-sm-4">
</div>
</div>
  </div>
