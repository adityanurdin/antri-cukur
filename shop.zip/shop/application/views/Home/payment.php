<div class="container">
<center><h1>Payment</h1>
  <br><br>
<h3>About payment, we only use BNI for payment your order<h3></center>
  <br>
  <center>
  <h4><p>Number of account : 453467638</p>
      <p>Name of account   : Muhammad Aditya Nurdin</p>
  </h4>
</center>
  <center><img src="<?= base_url();?>assets/images/bni.png" style="width:300px"></center>
</div>
