<div class="container">
<h1>Terms & Agreements</h1>
  <br><br>
  <h1><strong>SYARAT &amp; KETENTUAN</strong></h1>

  <p>Selamat datang di Preloved Shop  . Halaman ini berisi tentang Syarat dan Ketentuan mengenai barang atau jasa yang ditawarkan atau dijual (selanjutnya disebut &ldquo;<strong>Produk</strong>&rdquo;) yang terdaftar di Website kami&nbsp;<a href="http://shop.blog-empat.com/">www.shop.blog-empat.com</a>&nbsp;(selanjutnya disebut &ldquo;<strong>Website</strong>&rdquo;) kepada pengunjung website kami (selanjutnya disebut &ldquo;<strong>Pengguna</strong>&rdquo;). Harap Pengguna meluangkan waktu untuk membaca halaman Syarat dan Ketentuan sebelum memesan Produk di Website kami. Dengan mengunjungi atau membuat akun Pengguna di&nbsp;<a href="http://shop.blog-empat.com/">www.shop.blog-empat.com</a>&nbsp;Pengguna telah setuju untuk terikat secara hukum dan tunduk kepada Syarat dan Ketentuan ini.&nbsp;<a href="http://shop.blog-empat.com/">www.shop.blog-empat.com</a>&nbsp;berhak untuk mengubah Syarat &amp; Ketentuan sewaktu-waktu tanpa pemberitahuan dan atau tanpa persetujuan dari Pengguna. Harap luangkan waktu Pengguna untuk terus kembali mengunjungi dan mengetahui setiap perubahan yang kami buat dalam Syarat dan Ketentuan kami.</p>

  <h2><strong>TENTANG KAMI</strong></h2>

<p><a href="http://shop.blog-empat.com/">www.shop.blog-empat.com</a>&nbsp;didirikan oleh Muhammad Aditya Nurdin (selanjutnya disebut &ldquo;Pemilik&rdquo;). Segala tuntutan yang ataupun kendala di kemudian hari Pengguna setuju untuk tidak melimpahkan kepada pribadi Pemilik dan oleh sebab itu Pemilik tidak bertanggung jawab terhadap kendala yang diatur dalam Syarat &amp; Ketentuan ini.</p>
<h2><strong>DEFINISI</strong></h2>

<ol>
	<li>&ldquo;Produk&rdquo; berarti barang dan atau jasa yang disediakan oleh preloved shop.</li>
	<li>&ldquo;Pemilik&rdquo; berarti pribadi Satrya Putra Adhitama.</li>
	<li>&ldquo;Website&rdquo; berarti pengunjung website preloved shop.</li>
	<li>&ldquo;Kami atau kami&rdquo; berarti preloved shop.</li>
	<li>&ldquo;Pengguna&rdquo; berarti setiap individu yang mengunjungi dan atau melakukan pemesanan di Website.</li>
	<li>&ldquo;Pemesanan&rdquo; berarti pemesanan yang Pengguna lakukan di Website untuk membeli Produk.</li>
	<li>&ldquo;Persetujuan&rdquo; berarti pemesanan 1 (satu) Produk atau lebih sesuai dengan Syarat dan Ketentuan ini.</li>
	<li>&ldquo;Pengguna&rdquo; berarti pembaca Syarat dan Ketentuan ini.</li>
</ol>

<p>Referensi untuk &ldquo;pasal&rdquo; atau &ldquo;klausul&rdquo; adalah pasal atau klausula dalam Syarat dan Ketentuan ini;</p>

<p>&nbsp;</p>

<p>Judul dan sub judul dalam Syarat dan ketentuan hanya untuk kemudahan Pengguna dan tidak mempengaruhi langsung atau tidak langsung interpretasi dana tau konstruksi dari Syarat dan Ketentuan ini. Kata-kata yang menyebutkan sesuatu dalam bentuk tunggal dianggap termasuk mencakup jamak dan sebaliknya. Kata-kata yang menyampaikan gender meliputi setiap jenis kelamin dan referensi untuk individu, perusahaan, korporasi, atau kemitraan dan sebaliknya. Referensi untuk &ldquo;termasuk&rdquo; berarti tanpa batasan.</p>

<p>&nbsp;</p>

<h2><strong>PERSYARATAN</strong></h2>

<p>Untuk melakukan dan menempatkan Pemesanan di Website. Pengguna harus berusia lebih dari delapan belas (18) tahun. Jika Pengguna berusia di bawah delapan belas (18) tahun, Pengguna dapat menempatkan Pemesanan dengan preloved shop hanya dengan persetujuan orangtua atau wali Pengguna yang sah. Dengan membuat akun di website ini, Pengguna sudah menyetujui dan Pengguna dapat membuktikan bahwa Pengguna telah mendapat persetujuan dari orangtua atau wali Pengguna yang sah sebagai bukti jika dibutuhkan kemudian hari.&nbsp;www.shop.blog-empat.com tidak bertanggung jawab untuk segala kendala dan masalah yang ada di kemudian hari jika Pengguna tidak dapat membuktikan persetujuan dari orangtua atau wali Pengguna yang sah saat mendaftarkan diri di Website ini.</p>
<p> </p>
<h2><strong>Larangan</strong></h2>
<p>Pengguna tidak boleh menyalahgunakan Website ini. Pengguna dilarang untuk dan karenanya mengikatkan diri untuk:</p>
<ol>
<li>Tidak melakukan atau mendukung tindak pidana.</li>
<li>Tidak melakukan atau mendukung tindakan pelanggaran hukum.</li>
<li>Tidak mengirimkan, menyebarkan dan/atau mendistribusikan virus dalam bentuk apapun termasuk tetapi tidak terbatas pada <em>Trojan horse, worm, logic bomb.</em>
</li>
<li>Tidak mengirimkan atau memasukkan materi berbahaya dalam bentuk apapun ke atau dalam Website termasuk teknologi berbahaya.</li>
<li>Tidak melakukan tindakan pelanggaran hak pihak manapun termasuk hak atas kekayaan intelektual.</li>
<li>Tidak melakukan tindakan berpura-pura sebagai orang lain/entitas lain, memberikan keterangan, identitas atau informasi atau yang salah, tidak benar atau palsu, atau mengaku sebagai orang lain atau pihak tertentu.</li>
<li>Tidak dengan cara apapun melakukan tindakan, menuliskan atau menyebarkan hal-hal yang bersifat ofensif atau melecehkan.</li>
<li>Tidak memasuki atau mendapatkan akses yang tidak sah dan/atau mengganggu atau mengacaukan <em>system </em>komputer atau jaringan yang terhubung dengan Layanan atau Website.</li>
<li>Tidak merusak data.</li>
<li>Tidak menyebabkan gangguan terhadap pengguna lain, (k) melanggar asusila.</li>
<li>Melanggar hak kesopanan orang lain.</li>
<li>Tidak mengirim iklan atau materi promosi yang tidak diminta ke dalam Website, dan/atau</li>
<li>Mencoba untuk mempengaruhi kinerja atau fungsi dari setiap fasilitas komputer atau akses terhadap seluruh Website. Setiap pelanggaran atas Syarat dan Ketentuan ini merupakan tindak pidana berdasarkan Undang-Undang Nomor 11 Tahun 2008 tentang Informasi dan Transaksi Elektronik (ITE) dan Revisi Undang-Undang Nomor 19 Tahun 2016 tentang Informasi dan Transaksi Elektronik (ITE). Jika hal tersebut terjadi, preloved shop akan melaporkan pelanggaran tersebut kepada pihak penegak hukum yang berwenang dan akan diambil tindakan hukum sesuai dengan ketentuan hukum yang berlaku.</li>
</ol>
<p> </p>
<h2><strong>Keseluruhan Perjanjian</strong></h2>
<p>Syarat dan Ketentuan berlaku untuk semua Pemesanan dan Kontrak yang dibuat atau akan dibuat oleh kami untuk penjualan dan suplai Produk. Syarat dan Ketentuan, Kontrak dan kebijakan privasi yang diberlakukan oleh preloved shop merupakan keseluruhan perjanjian antara Pengguna dan preloved shop terkait dengan transaksi Pemesanan. Setiap pengesampingan satu atau lebih Syarat dan Ketentuan hanya akan berlaku efektif jika dibuat secara tertulis, resmi dan ditandatangani oleh orang yang memiliki hak dan wewenang untuk bertindak untuk dan atas nama preloved shop.</p>
<p>Pengguna mengakui bahwa, dalam melakukan Pemesanan maupun dalam memasuki atau menyetujui Persetujuan, baik Pengguna maupun kami tidak bergantung pada pernyataan, jaminan maupun janji yang diberikan oleh pihak manapun (termasuk tetapi tidak terbatas oleh pihak Pemasok) dalam bentuk apapun baik dalam bentuk tertulis maupun tidak tertulis dalam kata-kata diluar Syarat dan Ketentuan ini, kecuali secara tegas dinyatakan dalam Syarat dan Ketentuan ini.</p>
<p> </p>
<h2><strong>Persyaratan Penjualan</strong></h2>
<ol>
<li>Untuk menempatkan Pemesanan, Pengguna harus mendaftarkan diri di Website dengan membuat Akun di Website. Pengguna harus memberikan data diri secara lengkap dan sebenar-benarnya dan bertanggung jawab penuh terhadap data diri yang didaftarkan di Website. Pengguna wajib memperbaharui data diri jika terdapat perubahan dan memberi info kepada Kami. Jika mengalami kendala dalam memperbaharui data diri Pengguna, Pengguna dapat mengkomunikasikan kendala yang dihadapi ke <a href="mailto:mail@blog-empat.com">mail@blog-empat.com</a>
</li>
<li>Pengguna dilarang menggunakan beberapa Akun dengan entitas berbeda tanpa sepengetahuan Kami.</li>
</ol>
<p> </p>
<h2><strong>PRODUK RUSAK</strong></h2>

<ol>
	<li>Semua deskripsi, informasi, data, dan/atau materi dalam bentuk apapun (termasuk deskripsi mengenai Produk) yang diposting dalam Website ini disediakan &#39;apa adanya&#39; dan tanpa adanya pernyataan, jaminan maupun janji baik yang tersirat maupun yang tersurat atau makna apapun yang tersembunyi.</li>
	<li>Gambar Produk seperti yang terlihat di Website dapat sedikit berbeda dari Produk yang sebenarnya yang Pengguna terima.</li>
	<li>Jika Produk yang Pengguna terima rusak, silahkan hubungi Tim Customer Support kami dan memberikan nomor Pemesanan, nama dan alamat Pengguna, rincian Produk dan alasan pengembalian Produk, dan apakah Pengguna memerlukan pengembalian atau Produk pengganti.</li>
	<li>Setelah kami menerima Produk yang Pengguna kembalikan karena rusak, kami akan memeriksanya dan kami akan memberitahu Pengguna tentang hak Pengguna untuk penggantian Produk (jika ada) atau pengembalian dana melalui&nbsp;<em>e-mail</em>&nbsp;sesegera mungkin sesuai dengan Syarat dan Ketentuan yang berlaku.</li>
	<li>Dalam hal Pengguna mengembalikan kepada kami Produk yang tidak rusak, kami memiliki hak untuk memutuskan untuk tidak memperbaiki Produk tersebut atau mengganti Produk tersebut dengan Produk yang baru atau mengembalikan uang Pengguna. Kami juga berhak untuk mewajibkan Pengguna untuk membayar semua biaya yang telah kami keluarkan terkait dengan pemesanan maupun pengiriman Produk kepada Pengguna maupun dengan proses pengembalian Produk oleh Pengguna kepada kami sesuai dengan standar biaya kami yang berlaku pada saat tersebut, termasuk tetapi tidak terbatas pada biaya pelayanan biaya kartu kredit atau debit, maupun seluruh biaya maupun pembayaran sebagaimana tercantum dalam Pemesanan Pengguna. Sepanjang tidak bertentangan dengan hukum yang berlaku, kami tidak bertanggung jawab kepada Pengguna atas segala kerugian atau segala biaya, ongkos maupun pengeluaran yang Pengguna keluarkan atau Pengguna bayarkan.</li>
	<li><em>Lifetime Warranty</em>&nbsp;hanya berlaku bagi Pengguna jika telah mendapat persetujuan dari Kami.</li>
</ol>
<p> </p>
<h2><strong>Tanggung Jawab</strong></h2>
<ol>
<li>Seluruh isi, konten, materi, data, deskripsi, gambar maupun informasi yang ditampilkan di Website maupun yang ditempatkan atau terdapat dalam Website disediakan atau ditampilkan tanpa pernyataan, jaminan, janji, maupun garansi untuk akurasinya. Kecuali dinyatakan sebaliknya dalam Syarat dan Ketentuan ini dan sepanjang tidak melanggar hukum yang berlaku, kami, penyedia konten maupun pengiklan dengan ini secara tegas mengesampingkan semua pernyataan, jaminan, janji, garansi dan/atau persyaratan lain yang dapat dianggap diberikan atau tersirat dalam undang-undang, ketentuan hukum yang berlaku, hukum adat maupun kebiasaan pada umumnya serta tidak bertanggung jawab atas biaya, kerugian maupun kerusakan dalam bentuk apapun, termasuk tidak terbatas pada;</li>
<li>kerugian langsung, tidak langsung, khusus dan/atau konsekuensial,</li>
<li>kerugian atas kehilangan penggunaan, keuntungan, data atau wujud lainnya,</li>
<li>kerugian atas tercemarnya nama baik atau reputasi, maupun</li>
<li>biaya pengadaan Produk pengganti, masing-masing yang timbul dari atau terkait dengan penggunaan, ketidakmampuan untuk menggunakan, kinerja atau kegagalan dari Website dan/atau setiap isi, konten, materi, data, deskripsi, gambar maupun informasi yang ditampilkan pada Website maupun yang ditempatkan atau terdapat dalam Website.</li>
<li>Tidak ada ketentuan dalam Syarat dan Ketentuan ini yang mengecualikan atau membatasi kewajiban preloved shop atas terjadinya kematian atau cidera pribadi pada Pengguna yang timbul dari pelanggaran yang kami lakukan yang terbukti berdasarkan keputusan yang final dan sah dari pengadilan yang berwenang, penyampaian informasi dalam Website ini yang keliru, maupun karena hal-hal yang berdasarkan ketentuan hukum maupun peraturan perundang-undangan yang berlaku merupakan kewajiban kami yang bersifat <em>mandatory </em>dan tidak dapat dikesampingkan.</li>
<li>preloved shop tidak bertanggung jawab kepada Pengguna maupun kepada pihak lainnya atas</li>
<ol>
<li>Ketidakakuratan, kesalahan, kerusakan atau kerugian yang disebabkan baik oleh karena kegagalan, penundaan,</li>
<li>Terputusnya Layanan,</li>
<li>Isi, konten, materi, data, deskripsi, gambar maupun informasi yang ditampilkan pada Website maupun yang ditempatkan atau terdapat dalam Website dan/atau</li>
<li>Penggunaan Website oleh Pelanggan maupun pihak manapun. Sehubungan dengan hal tersebut, Pelanggan menyetujui bahwa Pelanggan tidak dapat mengajukan klaim, gugatan dan/atau tuntutan dalam bentuk apapun kepada preloved shop atas segala kerugian atau kerusakan yang timbul.</li>
</ol>
</ol>
<p> </p>
<h2><strong>Ganti Rugi</strong></h2>
<p>Pengguna wajib dan dengan ini setuju untuk mengganti seluruh kerugian yang dialami oleh Kami, serta membela dan membebaskan Perusahaan maupun direktur, pejabat, karyawan, konsultan, agen, dan afiliasi dari Perusahaan dari setiap dan semua (a) klaim, teguran, tuntutan dan/atau gugatan dari pihak manapun dalam bentuk apapun, (b) kewajiban, kerusakan, pengeluaran dan/atau biaya (termasuk namun tidak terbatas pada, biaya hukum) yang timbul atau dialami, masing-masing sehubungan dengan atau sebagai akibat dari penggunaan Website ini oleh Pengguna atau pelanggaran Pengguna terhadap Syarat dan Ketentuan ini.</p>
<p> </p>
<h2><strong>Perlindungan Data Pribadi</strong></h2>
<p>Silakan lihat kebijakan privasi kami yang merupakan bagian dari Syarat dan Ketentuan ini.</p>
<p> </p>
<h2><strong>Variasi</strong></h2>
<p>Kami berhak untuk mengubah Syarat dan Ketentuan ini setiap waktu yang akan kami posting secara <em>online</em> sebagai pemberitahuan kepada Pengguna. Penggunaan Website akan dianggap merupakan penerimaan Syarat dan Ketentuan yang berlaku pada saat tersebut.</p>
<p>Ketika Pengguna mengirimkan Pemesanan ke Website, Pengguna setuju bahwa Pengguna melakukannya dan tunduk pada Syarat dan Ketentuan yang berlaku pada tanggal yang Pengguna kirimkan pada Pemesanan Pengguna. Pengguna bertanggung jawab untuk membaca, meninjau dan mengerti Syarat dan Ketentuan yang terbaru setiap kali Pengguna mengirimkan Pemesanan Pengguna.</p>
<p> </p>






</div>
