<div class="container-fluid">
<div class="row">
  <div class="col-sm-2">
  </div>
  <div class="col-sm-8">
    <div id="demo" class="carousel slide" data-ride="carousel">
      <ul class="carousel-indicators">
        <li data-target="#demo" data-slide-to="0" class="active"></li>
        <li data-target="#demo" data-slide-to="1"></li>
      </ul>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="<?= base_url(); ?>assets/images/foto_barang/jeans.jpg" class="rounded" alt="under_construction" width="100%">
          <div class="carousel-caption">
              <h6 class="w3-jumbo w3-hide-small"><mark>PRELOVED SHOP</mark></h6>
              <h6 class="w3-hide-large w3-hide-medium"><mark>PRELOVED SHOP</mark></h6>
              <h6 class="w3-hide-small"><mark>Monday - Friday : 08.00 - 16.00</mark></h6>
              <h6 class="w3-hide-small"><mark>Saturday - Sunday : 08.00 - 15.00</mark></h6>
            <p><a href="<?= base_url(); ?>pages/shop" class="btn btn-dark w3-padding-large w3-large">SHOP NOW</a></p>
          </div>
        </div>
        <div class="carousel-item">
          <img src="<?= base_url(); ?>assets/images/foto_barang/camera.jpg" class="rounded" alt="under_construction" width="100%">
          <div class="carousel-caption">
            <h6 class="w3-jumbo w3-hide-small"><mark>SHOP EXCLUSIVE</mark></h6>
            <h6 class="w3-hide-large w3-hide-medium"><mark>SHOP EXCLUSIVE</mark></h6>
            <h6 class="w3-hide-small"><mark><i>"make, serve and ship with premium quality"</i></mark></h6>
          <p><a href="<?= base_url(); ?>pages/shop" class="btn btn-dark w3-padding-large w3-large">SHOP NOW</a></p>
          </div>
        </div>
      </div>
      <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </a>
      <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
      </a>
    </div>
    <br>
     <div class="w3-col l3 s6">
        <div class="w3-display-container">
          <img src="<?= base_url();?>/assets/images/foto_barang/kurta1.png" class="img-responsive" style="width:100%">
          <span class="w3-tag w3-display-topleft">SALE</span>
          <div class="w3-display-middle w3-display-hover">
            <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
          </div>
        </div>
        <p>Setelan Kurta Delica<br><b class="w3-text-red">Rp.190.000</b></p>
    </div>
    <div class="w3-col l3 s6">
       <div class="w3-display-container">
         <img src="<?= base_url();?>/assets/images/foto_barang/jeans2.jpg" class="img-responsive" style="width:100%">
         <span class="w3-tag w3-display-topleft">NEW</span>
         <div class="w3-display-middle w3-display-hover">
           <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
         </div>
       </div>
       <p>Mega Ripped Jeans<br><b class="w3-text-red">$19.99</b></p>
   </div>
   <div class="w3-col l3 s6">
      <div class="w3-display-container">
        <img src="<?= base_url();?>/assets/images/foto_barang/jeans3.jpg" class="img-responsive" style="width:100%">
        <span class="w3-tag w3-display-topleft"></span>
        <div class="w3-display-middle w3-display-hover">
          <button class="w3-button w3-black">Buy now <i class="fa fa-shopping-cart"></i></button>
        </div>
      </div>
      <p>Washed Skinny Jeans<br><b class="w3-text-red">$20.50</b></p>
  </div>
   <div class="w3-col l3 s6">
      <div class="w3-display-container">
        <img src="<?= base_url();?>/assets/images/foto_barang/jeans1.jpg" class="img-responsive" style="width:100%">
        <div class="w3-display-middle w3-display-hover">
          <a href="<?= base_url(); ?>pages/shop"><button class="w3-button w3-black">AND MORE <i class="fa fa-arrow-right"></i></button></a>
        </div>
      </div>
  </div>


</div>
<div class="col-sm-4">
</div>
</div>
  </div>
