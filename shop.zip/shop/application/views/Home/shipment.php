<div class="container">
<center><h1>Shipment</h1>
  <br><br>
<h3>About shipment, we only use JNE for shipping your order<h3></center>
  <br><br>
  <center><img src="<?= base_url();?>assets/images/jne.png" style="width:500px"></center>
</div>
