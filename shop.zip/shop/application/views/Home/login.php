<div class="container">
  <?php if ($this->session->flashdata('Register') == NULL) {
    echo "";
  }else{
    echo
    "<div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert'>&times;</button>
    ".$this->session->flashdata('Register')."
    </div>";
  }
  ?>
  <div class="row">
    <!-- LOGIN -->
  <div class="col-sm-4">
    <center><h3><b>Login</b></h3></center>
<?= form_open('Auth/login'); ?>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" name="email" required>
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" name="password" required>
    <input type="number" name="user_type" value="1" hidden="">
  </div>
  <div class="form-group form-check">
    <label class="form-check-label">
      <input class="form-check-input" type="checkbox"> Remember me
    </label>
  </div>
  <center>
  <button type="submit" name="submit" class="btn btn-primary">Login</button>
</center>
</form>
</div>
<div class="col-sm-4">
  <center>
  <p><h2><b><i>OR</i></b></h2></p>
  <!-- <hr>
  <p>welcome to preloved shoppers -->
</center>
</div>
<!-- REGISTER -->
<div class="col-sm-4">
  <center><h3><b>Register</b></h3></center>
<?= form_open('auth/user_register'); ?>
  <div class="form-group">
    <label for="pwd">First name:</label>
    <input type="text" class="form-control" name="first_name" required>
  </div>
  <div class="form-group">
    <label for="pwd">Last name:</label>
    <input type="text" class="form-control" name="last_name" required>
  </div>
<div class="form-group">
  <label for="email">Email address:</label>
  <input type="email" class="form-control" name="email" required>
</div>
<div class="form-group">
  <label for="pwd">Password:</label>
  <input type="password" class="form-control" name="password" required>
  <input type="number" name="user_type" value="1" hidden="">
</div>
<!-- <div class="form-group">
  <label for="pwd">Re-password:</label>
  <input type="password" class="form-control" name="re-password" required>
</div> -->
<div class="form-group form-check">
  <label class="form-check-label">
    <input class="form-check-input" type="checkbox" required> <a href="<?= base_url();?>pages/terms_and_agreements">I agree with terms & agreements</a>
  </label>
</div>
<center>
<button type="submit" name="submit" class="btn btn-primary">Register</button>
</center>
</form>
</div>
</div>
</div>
