<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="shortcut icon" href='<?= base_url();?>/assets/images/icon2.ico'>
  <title>Preloved Shop</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"> -->
  <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script> -->
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script> -->
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
  <!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
  <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/bootstrap.min.css">
  <script src="<?= base_url(); ?>/assets/js/jquery.min.js"></script>
  <script src="<?= base_url();?>/assets/umd/popper.min.js"></script>
  <script src="<?= base_url(); ?>/assets/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="<?= base_url();?>/assets/css/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?= base_url();?>/assets/css/font-awesome.min.css">

  <style>
  body  {
    background-color: #ffff99;
        }
  </style>
  <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
</head>
<body style="body" data-spy="scroll">

<nav class="navbar navbar-expand-lg bg-warning navbar-light">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="<?= base_url();?>/assets/images/icon2.png" alt="logo" style="width:40px;">
    PRELOVED SHOP
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href='<?= base_url();?>'>Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?= base_url(); ?>Pages/shop">Shop</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Payment Confirmation</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">FAQ</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#footer">Contact</a>
    </li>
  </ul>
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <a href="<?= base_url();?>pages/login"><button class="btn btn-dark"><i class="fa fa-user"></i> Login</button></a>

</div>
</nav>
<br>
<?= $contents; ?>
</body>
<br><br><br>
<!-- Footer -->
  <footer class="w3-padding-64 w3-light-grey w3-small w3-center" id="footer">
    <div class="w3-row-padding">
      <div class="w3-col s4">
        <h4>Contact</h4>
        <p>Questions? Go ahead.</p>
        <form action="/action_page.php" target="_blank">
          <p><input class="w3-input w3-border" type="text" placeholder="Name" name="Name" required></p>
          <p><input class="w3-input w3-border" type="text" placeholder="Email" name="Email" required></p>
          <p><input class="w3-input w3-border" type="text" placeholder="Subject" name="Subject" required></p>
          <p><input class="w3-input w3-border" type="text" placeholder="Message" name="Message" required></p>
          <button type="submit" class="w3-button w3-block w3-black">Send</button>
        </form>
      </div>

      <div class="w3-col s4">
        <h4>About</h4>
        <p><a href="<?= base_url();?>pages/terms_and_agreements">Terms & Agreements</a></p>
        <p><a href="#">We're hiring</a></p>
        <!-- <p><a href="#">Support</a></p> -->
        <!-- <p><a href="#">Find store</a></p> -->
        <p><a href='<?= base_url();?>pages/shipment'>Shipment</a></p>
        <p><a href='<?= base_url();?>pages/payment'>Payment</a></p>
        <p><a href="#">Help</a></p>
      </div>

      <div class="w3-col s4 w3-justify">
        <h4>Store</h4>
        <p><i class="fa fa-fw fa-map-marker"></i> Bogor</p>
        <p><i class="fa fa-fw fa-phone"></i> 085883679450</p>
        <p><i class="fa fa-fw fa-envelope"></i> <a href="mailto:mail@blog-empat.com">mail@blog-empat.com</a></p>
        <a href="https://facebook.com/adityanurdin0" target="_blank"<i class="fa fa-facebook-official w3-hover-opacity w3-large"></i></a>
        <a href="https://instagram.com/aditya252" target="_blank"><i class="fa fa-instagram w3-hover-opacity w3-large"></i></a>
        <!-- <i class="fa fa-snapchat w3-hover-opacity w3-large"></i> -->
        <!-- <i class="fa fa-pinterest-p w3-hover-opacity w3-large"></i> -->
        <!-- <i class="fa fa-twitter w3-hover-opacity w3-large"></i> -->
        <!-- <i class="fa fa-linkedin w3-hover-opacity w3-large"></i> -->
      </div>
    </div>
  </footer>
  <div class="w3-black w3-center w3-padding-24">&copy; Aditya Nurdin <?php echo date('Y') ?></div>

</html>
