<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');
 ?>
<br><br><br>
<h2>New Product</h2>
  <?= form_open_multipart('Dashboard/add_product') ?>
<div class="col-sm-8">
  <input type="text" value="<?= $date ?>" hidden="" name="tanggal_produk">
  <br>
  <p><b>Name Product</b></p>
<input type="text" class="form-control"   name="nama_produk" required="">
<br>
<p><b>Category</b></p>
            <select name="kategori_id" class="form-control">
                <?php
                foreach ($kategori as $k)
                {
                    echo "<option value='$k->id_kategori'>$k->nama_kategori</option>";
                }
                ?>
            </select>

<br>
<p><b>Price Product</b></p>
<input type="number" class="form-control"   name="harga_produk" required="">
<br>
<p><b>Size Product</p>
<div class="form-check-inline">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="ukuran_produk1" value="S">S
  </label>
</div>
<div class="form-check-inline">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="ukuran_produk2" value="M">M
  </label>
</div>
<div class="form-check-inline">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="ukuran_produk3" value="L">L
  </label>
</div>
<div class="form-check-inline">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="ukuran_produk4" value="XL">XL
  </label>
</div></b>
<br><br>
<p><b>Total Product</b></p>
<input type="number" class="form-control"   name="jumlah_produk" required="">
<br>
<!-- upload gambar -->
<p><b>Image 1 : </b></p>
<input type="file" name="userfiles_1" size="20" required="" class="form-control-file border"/>
Gambar tidak boleh melebihi 1Mb
<br>
<p><b>Image 2 : </b></p>
<input type="file" name="userfiles_2" size="20" required="" class="form-control-file border"/>
Gambar tidak boleh melebihi 1Mb
<!-- <br>
<p><b>Image 3 : </b></p>
<input type="file" name="userfiles[]" size="20" required="" class="form-control-file border"/>
Gambar tidak boleh melebihi 1Mb -->
<br><br>
<p><b>Description Product</b></p>
<textarea id="ckeditor" class="form-control" rows="20" name="deskripsi_produk" required="">Description... Product</textarea>
<br><br>
<button type="submit" name="submit" class="btn btn-primary">Post</button>
<br><br>
</form>
</div>

<script>
var ckeditor = CKEDITOR.replace('ckeditor',{
                  height:'300px'
});

CKEDITOR.disableAutoInline = true;
CKEDITOR.inline('editable');
</script>
