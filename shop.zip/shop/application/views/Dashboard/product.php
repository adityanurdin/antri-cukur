<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');

 ?>
<br><br><br>
<div class="container">


  <?php if ($this->session->flashdata('message_add') == NULL) {
    echo "";
  }else{
    echo
    "<div class='alert alert-success alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert'>&times;</button>
    ".$this->session->flashdata('message_add')."
    </div>";
  }

  if ($this->session->flashdata('message_delete') == NULL) {
    echo "";
  }else {
    echo
    "<div class='alert alert-danger alert-dismissible fade show'>
    <button type='button' class='close' data-dismiss='alert'>&times;</button>
    ".$this->session->flashdata('message_delete')."
    </div>";
  }
  ?>

  <h2>Product</h2>
  <br>
  <div class="col-sm-4">
  <a href="<?= base_url();?>Dashboard/add_product" class="btn btn-success">Add Product</a>
  <br><br>
  <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search Product" title="Type in a name">
</div>
<br>
<div class="table-responsive">
  <table class="table table-dark table-hover" id="myTable">
    <thead>
      <tr>
        <th>No</th>
        <th>Product</th>
        <th>Category</th>
        <th>Price</th>
        <th>Size Product</th>
        <th>Total</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      foreach ($record as $r) {
        if ($r->status_produk == 0) {
          echo "
                <tr>
                <td>$no</td>
                <td>$r->nama_produk</td>
                <td>$r->nama_kategori</td>
                <td>Rp".number_format($r->harga_produk).",00</td>
                <td>$r->ukuran_produk1 $r->ukuran_produk2 $r->ukuran_produk3 $r->ukuran_produk4</td>
                <td>$r->jumlah_produk</td>
                <td>
                  <a href='".base_url()."Dashboard/delete_product/$r->produk_id' class='btn btn-danger hapus'><i class='fa fa-trash-o' aria-hidden='true'></i> Delete</a>
                  <a href='".base_url()."Dashboard/edit_product/$r->slug_produk' class='btn btn-warning'><i class='fa fa-pencil-square-o' aria-hidden='true'></i> Edit</a>
                  <a href='".base_url()."Dashboard/hide_product/$r->produk_id' class='btn btn-info'><i class='fa fa-eye-slash' aria-hidden='true'></i> Hide</a>
                </td>
                </tr>
                ";
        }elseif ($r->status_produk == 1) {
          echo "
                <tr>
                <td>$no</td>
                <td>$r->nama_produk</td>
                <td>$r->nama_kategori</td>
                <td>$r->harga_produk</td>
                <td>$r->ukuran_produk1 $r->ukuran_produk2 $r->ukuran_produk3 $r->ukuran_produk4</td>
                <td>$r->jumlah_produk</td>
                <td>
                  <a href='".base_url()."Dashboard/delete_product/$r->produk_id' class='btn btn-danger hapus'><i class='fa fa-trash-o' aria-hidden='true'></i> Delete</a>
                  <a href='".base_url()."Dashboard/edit_product/$r->slug_produk' class='btn btn-warning'><i class='fa fa-pencil-square-o' aria-hidden='true'></i> Edit</a>
                  <a href='".base_url()."Dashboard/unhide_product/$r->produk_id' class='btn btn-info'><i class='fa fa-eye-slash' aria-hidden='true'></i> Unhide</a>
                </td>
                </tr>
                ";
        }
        $no++;
        }
       ?>
    </tbody>
  </table>
</div>
</div>
<script>
    $(".hapus").click(function () {
        var jawab = confirm("Are you sure for delete this product ?");
        if (jawab === true) {
//            kita set hapus false untuk mencegah duplicate request
            var hapus = false;
            if (!hapus) {
                hapus = true;
                $.post('hapus.php', {id: $(this).attr('data-id')},
                function (data) {
                    alert(data);
                });
                hapus = false;
            }
        } else {
            return false;
        }
    });
</script>
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
