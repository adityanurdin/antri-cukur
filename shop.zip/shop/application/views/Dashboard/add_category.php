<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');
 ?>
 <br><br><br>
 <h2>Create Category</h2>
   <?= form_open_multipart('Dashboard/add_category') ?>
 <div class="col-sm-8">
   <input type="text" value="<?= $date ?>" hidden="" name="tanggal_kategori">
   <br>
   <p><b>Name Category</b></p>
 <input type="text" class="form-control"   name="nama_kategori" required="">
 <br>
 <button type="submit" name="submit" class="btn btn-primary">Create</button>
 <br><br>
 </form>
 </div>
