<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');

 ?>
<br><br><br>
<div class="container">
  <h2>Category</h2>
  <br>
  <div class="col-sm-8">
  <a href="<?= base_url();?>Dashboard/add_category" class="btn btn-success">Create Category</a>
  <br><br>
  <!-- <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search Product" title="Type in a name"> -->

<br>
  <table class="table table-dark table-hover" id="myTable">
    <thead>
      <tr>
        <th>No</th>
        <th>Category</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($record as $r) {
        $no = 1;
        echo "
          <tr>
          <td>$no</td>
          <td>$r->nama_kategori</td>
          <td>
            <a href='".base_url()."Dashboard/delete_product/$r->id_kategori' data-toggle='modal' data-target='#myModal' class='btn btn-danger'><i class='fa fa-trash-o' aria-hidden='true'></i> Delete</a>
            <a href='".base_url()."Dashboard/edit_product/$r->id_kategori' class='btn btn-warning'><i class='fa fa-pencil-square-o' aria-hidden='true'></i> Edit</a>
          </td>
          </tr>

        ";
        $no++;
      } ?>
    </tbody>
  </table>
  </div>
  <div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h5 class="modal-title">Are you sure for delete this product ?</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <!-- <?= form_open_multipart('Dashboard/add_product') ?>
        <input type="text" value="<?= $date ?>" hidden="" name="tanggal_produk">
        <?php
        foreach ($record as $r) {
          echo '<input type="text" value="'.$r->nama_produk.'" hidden="" name="nama_produk">';
        }
         ?>
        <?php echo "<a href='".base_url()."Dashboard/delete_product/$r->produk_id' name='submit' class='btn btn-success'>Yes</a>"; ?> <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
      </div> -->

    </div>
  </div>
</div>
</div>
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
