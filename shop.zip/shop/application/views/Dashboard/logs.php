<br><br><br>
<div class="container">
  <h2>Logs Activity</h2>
  <br>
<br>
<tr class="table-borderless table-active">
  <td><a href="#" class="btn btn-info"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Export Log(s) to PDF</a></td>
  <td><a href="#" class="btn btn-warning"><i class="fa fa-file-excel-o" aria-hidden="true"></i> Export Log(s) to EXCEL</a></td>
</tr>
<div class="table-responsive">
  <table class="table table-hover" id="myTable">
    <thead>
      <tr class="table-dark">
        <th>No</th>
        <th>Log Time</th>
        <th>Log User</th>
        <th>Log Desc</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      foreach ($record as $r) {

        if ($r->log_tipe == 0) {
          echo "
                <tr  class='table-success'>
                <td>$no</td>
                <td>$r->log_time</td>
                <td>$r->log_user</td>
                <td>$r->log_desc</td>
                </tr>
                ";
        }if ($r->log_tipe == 1) {
          echo "
                <tr  class='table-dark'>
                <td>$no</td>
                <td>$r->log_time</td>
                <td>$r->log_user</td>
                <td>$r->log_desc</td>
                </tr>
                ";
        }if ($r->log_tipe == 2) {
          echo "
                <tr  class='table-primary'>
                <td>$no</td>
                <td>$r->log_time</td>
                <td>$r->log_user</td>
                <td>$r->log_desc</td>
                </tr>
                ";
        }if ($r->log_tipe == 3) {
          echo "
                <tr  class='table-warning'>
                <td>$no</td>
                <td>$r->log_time</td>
                <td>$r->log_user</td>
                <td>$r->log_desc</td>
                </tr>
                ";
        }if ($r->log_tipe == 4) {
          echo "
                <tr  class='table-danger'>
                <td>$no</td>
                <td>$r->log_time</td>
                <td>$r->log_user</td>
                <td>$r->log_desc</td>
                </tr>
                ";
        }
      $no++;
    }
       ?>
    </tbody>
  </table>
</div>
</div>
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
