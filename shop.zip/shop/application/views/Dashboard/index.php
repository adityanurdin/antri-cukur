<br><br><br>
<div class="container">
  <h2><center>Welcome to Shop Dashboard</center></h2>
  <br>
  <h3>Total Income : Rp.1.000.000.000</h3>
  <h3>Total Product : <?= $data ?></h3>
  <!-- <h4>Progress : </h4>
<div class="progress" style="height:20px">
  <div class="progress-bar" style="width:80%;height:20px">Shop 80%</div>
</div>
<br>
<div class="progress" style="height:20px">
  <div class="progress-bar bg-danger" style="width:40%;height:20px"></div>
</div>
<br>
<div class="progress" style="height:20px">
  <div class="progress-bar bg-warning" style="width:60%;height:20px"></div>
</div> -->
<br>
</div>
