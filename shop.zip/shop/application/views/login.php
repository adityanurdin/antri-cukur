<!DOCTYPE html>
<html lang="en">
<head>
  <title>SHOP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"> -->
  <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script> -->
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script> -->
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
  <!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
  <link rel="stylesheet" href="<?= base_url(); ?>/assets/css/bootstrap.min.css">
  <script src="<?= base_url(); ?>/assets/js/jquery.min.js"></script>
  <script src="<?= base_url();?>/assets/umd/popper.min.js"></script>
  <script src="<?= base_url(); ?>/assets/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="<?= base_url();?>/assets/css/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?= base_url();?>/assets/css/font-awesome.min.css">

  <style>
  body  {
    background-color: #ffff99;
        }
  </style>
  <script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
</head>
<body style="body" data-spy="scroll">

<nav class="navbar navbar-expand-lg bg-warning navbar-light">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="<?= base_url();?>/assets/images/icon2.png" alt="logo" style="width:40px;">
    SHOP-Dashboard
  </a>
</nav>
<br><br><br>
<div class="container-fluid">
  <div class="row">
  <div class="col-sm-4">
  </div>
  <div class="col-sm-4">
    <?php
    date_default_timezone_set('Asia/Jakarta');
    $date = date('Y-m-d h:i:s');

     ?>
    <form <?= form_open('Auth/login'); ?>
      <input type="text" name="tanggal_login" value="<?= $date ?>" hidden="">
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" name="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" name="password">
    <input type="number" name="user_type" value="0" hidden="">
  </div>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>
  </div>
  <div class="col-sm-6">
  </div>
</div>
</div>
<br>
</body>
<br><br><br>
</html>
