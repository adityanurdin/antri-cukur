<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_product extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function view_product()
  {
    // $this->db->order_by('tanggal_produk', 'DESC');
    // $query = $this->db->get('produk');
    // return $query;
    $this->db->join('kategori','produk.kategori_id=kategori.id_kategori');
    $this->db->order_by('tanggal_produk', 'DESC');
    $query=$this->db->get('produk');
    return $query;

  }

  function add_product($data)
    {
        $this->db->insert('produk',$data);
    }

  function delete_product($id)
    {
      $this->db->where('produk_id' , $id);
      $query = $this->db->get('produk');
      // $row = $query->row();
      // unlink("./assets/images/foto_artikel/$row->foto");
      $this->db->delete('produk', array('produk_id' => $id));
    }

    function get_one($id)
    {
      $param = array('produk_id' => $id);
      return $this->db->get_where('produk' , $param);
    }

  function hide_product($id,$data)
  {
    $this->db->where('produk_id' , $id);
    $this->db->update('produk' , $data);
  }

  function unhide_product($id,$data)
  {
    $this->db->where('produk_id' , $id);
    $this->db->update('produk' , $data);
  }


  // function get_post_by_slug($slug)
  //   {
  //     $query=$this->db->query("SELECT * FROM produk WHERE slug_produk='$slug'");
  //     return $query;
  //   }
}
