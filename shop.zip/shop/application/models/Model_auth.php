<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_auth extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function login($email , $password)
  {
    $check = $this->db->get_where('auth' , array('email' => $email , 'password' => md5($password)));
    if ($check->num_rows()>0){
        return 1;
    }else{
        return 0;
    }
  }

  function register($data)
  {
    $this->db->insert('auth',$data);
  }

}
