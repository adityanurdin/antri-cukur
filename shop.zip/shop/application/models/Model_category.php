<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_category extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function view_category()
  {
    // $this->db->order_by('tanggal_produk', 'DESC');
    $query = $this->db->get('kategori');
    return $query;
  }

  function add_category($data)
    {
        $this->db->insert('kategori',$data);
    }

}
