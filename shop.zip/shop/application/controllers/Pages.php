<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function index()
  {
    $this->template->load('template' , 'Home/home');
  }

  function shop()
  {
    $this->template->load('template' , 'Home/shop');
  }

  function login()
  {
    if(isset($_POST['submit'])){
      $email = $this->input->post('email');
      $password = $this->input->post('password');
      $hasil = $this->Model_auth->login($email,$password);
      if ($hasil==1){
        $this->session->set_userdata(array('status_login'=>'oke'));
        redirect('Index/index');
      }
      else {
        redirect('Auth/login');
      }
    }
    else {
      // $this->load->view('Login_view');
      $this->template->load('template' , 'Home/login');
    }
  }

  function shipment()
  {
    $this->template->load('template' , 'Home/shipment');
  }

  function payment()
  {
    $this->template->load('template' , 'Home/payment');
  }

  function terms_and_agreements()
  {
    $this->template->load('template' , 'Home/terms_agreements');
  }

}
