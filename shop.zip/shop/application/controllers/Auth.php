<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
    $this->load->model('Model_auth');
    $this->load->model('m_log');
  }

  function index()
  {
  redirect('Auth/login');
  }

  function login()
  {
    if (isset($_POST['submit'])) {
      $email          = $this->input->post('email');
      $password       = $this->input->post('password');
      $tanggal_login  = $this->input->post('tanggal_login');
      $user_type      = $this->input->post('user_type');
        $hasil  = $this->Model_auth->login($email , $password);
        if ($hasil  == 1) {
          $this->session->set_userdata(array('status_login'=>'oke',
                                             'email' => $email
                                             ));
          if ($user_type == 0) {
            helper_log("login", "Sign in");
            redirect('Dashboard');
          }else{
            redirect('Home');
          }
        }if ($user_type == 0) {
          redirect('Auth/login');
        }else {
          redirect('Pages/login');
        }
    }else {
      check_session_login();
      $this->load->view('login');
    }
    // if(check_session_login_user()) {
    //   $this->template->load('template' , 'Home/login');
    // }
  }

  function user_register()
  {
    if (isset($_POST['submit'])) {

    $first_name       =   $this->input->post('first_name');
    $last_name        =   $this->input->post('last_name');
    $email            =   $this->input->post('email');
    $password         =   md5($this->input->post('password'));
    $code             =   rand(3333,99999);
    $user_type        =   $this->input->post('user_type');
    $data       = array('first_name'     =>  $first_name,
                        'last_name'    =>  $last_name,
                        'email'   =>  $email,
                        'password'  =>  $password,
                        'code'     =>  $code);
    $this->Model_auth->register($data);
    $this->session->set_flashdata('Register', "Registration success, please cheack your email and copy a code for active your account");
    if ($user_type == 0) {
      redirect('Auth/login');
    }else{
      redirect('Pages/login');
    }
  }else {
    $this->template->load('user_template' , 'Home/login');
  }
  }

  function logout()
  {
    // tanggal
  date_default_timezone_set('Asia/Jakarta');
  $date = date('Y-m-d h:i:s');
  // log
  helper_log("logout", "Sign out");
  // logout
  $this->session->sess_destroy();
  redirect('Auth/login');
}
function logout_user()
{
  // tanggal
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');
// log
// helper_log("logout", "Sign out");
// logout
$this->session->sess_destroy();
redirect('Pages');
}

}
