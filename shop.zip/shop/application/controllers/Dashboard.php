<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
    $this->imagepath = realpath(APPPATH.'./assets/images/foto_barang/');
      check_session();
      $this->load->model('Model_product');
      $this->load->model('m_log');
      $this->load->model('Model_category');
  }

  function index()
  {
    // $this->load->view('Dashboard/index');
    $data = $this->db->get('produk')->num_rows();
    $this->template->load('template-dashboard' , 'Dashboard/index' , compact('data'));
  }

  function product()
  {
    $data['record'] = $this->Model_product->view_product()->result();
    $this->template->load('template-dashboard' , 'Dashboard/product' , $data);
  }
  function add_product()
  {
    if (isset($_POST['submit'])) {
      // $number_of_files = sizeof($_FILES['userfiles']['tmp_name']);
      //
      // $config['upload_path']          = $this->imagepath;
      // $config['allowed_types']        = 'gif|jpg|png';
      // $config['max_size']             = 1024;
      // // $config['max_width']            = 1366;
      // // $config['max_height']           = 768;
      // $new_name = time().$_FILES["userfiles"]['name'];
      // $config['file_name'] = $new_name;
      // $this->load->library('upload', $config);
      // $this->upload->do_upload();
      // $hasil = $this->upload->data();
            // proses barang
            $nama_produk        =   $this->input->post('nama_produk');
            $harga_produk       =   $this->input->post('harga_produk');
            $jumlah_produk      =   $this->input->post('jumlah_produk');
            $tanggal_produk     =   $this->input->post('tanggal_produk');
            $slug_produk        =   slug($this->input->post('nama_produk'));
            $deskripsi_produk   =   $this->input->post('deskripsi_produk');
            $ukuran_produk1        =   $this->input->post('ukuran_produk1');
            $ukuran_produk2        =   $this->input->post('ukuran_produk2');
            $ukuran_produk3        =   $this->input->post('ukuran_produk3');
            $ukuran_produk4        =   $this->input->post('ukuran_produk4');
            $kategori_id           =   $this->input->post('kategori_id');
            $data       = array('nama_produk'     =>  $nama_produk,
                                'harga_produk'    =>  $harga_produk,
                                'jumlah_produk'   =>  $jumlah_produk,
                                'tanggal_produk'  =>  $tanggal_produk,
                                'slug_produk'     =>  $slug_produk,
                                'deskripsi_produk'=>  $deskripsi_produk,
                                'ukuran_produk1'     =>  $ukuran_produk1,
                                'ukuran_produk2'     =>  $ukuran_produk2,
                                'ukuran_produk3'     =>  $ukuran_produk3,
                                'ukuran_produk4'     =>  $ukuran_produk4,
                                'kategori_id'        =>  $kategori_id);
            $this->Model_product->add_product($data);
            $this->session->set_flashdata('message_add', "Success add <b>$nama_produk</b>");
            helper_log("add", "Adding a product : <b>$nama_produk</b>");
            redirect('Dashboard/product');
    }else {
      $data['kategori']   =  $this->Model_category->view_category()->result();
      $data['record'] = $this->Model_product->view_product()->result();
      $this->template->load('template-dashboard' , 'Dashboard/add_product' , $data);
    }
  }

  function delete_product()
  {
    $id = $this->uri->segment(3);
    $this->Model_product->delete_product($id);
    $this->session->set_flashdata('message_delete', "Success delete <b>$nama_produk</b>");
      helper_log("delete", "Delete $nama_produk");
      redirect('Dashboard/product');

  }

  function category()
  {
    $data['record'] = $this->Model_category->view_category()->result();
    $this->template->load('template-dashboard' , 'Dashboard/category' , $data );
  }

  function add_category()
  {
    if (isset($_POST['submit'])) {
    $kategori         = $this->input->post('nama_kategori');
    $tanggal_kategori  = $this->input->post('tanggal_kategori');
    $data     = array('nama_kategori' => $kategori);
    $this->Model_category->add_category($data);
    helper_log("add", "Create a category : <b>$kategori</b>");
    redirect('Dashboard/category');
  }else {
    $data['record'] = $this->Model_category->view_category()->result();
    $this->template->load('template-dashboard' , 'Dashboard/add_category' , $data);
    // $this->template->load('template-dashboard' , 'Admin/genre' , $data);
  }
  }

  function hide_product()
  {
    $status_produk = 1;
    $data = array('status_produk' => $status_produk);
    $id = $this->uri->segment(3);
    $this->Model_product->hide_product($id,$data);
    $data['record'] = $this->Model_product->get_one($id)->row_array();
    // $data = $record;
    // echo $record->nama_produk;
    helper_log("edit", "Hide a product  : ");
    redirect('Dashboard/product');
  }

  function unhide_product()
  {
    $status_produk = 0;
    $data = array('status_produk' => $status_produk);
    $id = $this->uri->segment(3);
    $this->Model_product->hide_product($id,$data);
    helper_log("edit", "Unhide a product : ");
    redirect('Dashboard/product');
  }

  function logs()
  {
    $data['record'] = $this->m_log->view_log()->result();
    $this->template->load('template-dashboard' , 'Dashboard/logs' , $data);
  }

}
