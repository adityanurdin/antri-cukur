<?php

  function check_session()
  {
    $CI = & get_instance();
    $session = $CI->session->userdata('status_login');
    if ($session!='oke') {
      redirect('Auth/login');
    }
  }

  function check_session_user()
  {
    $CI = & get_instance();
    $session = $CI->session->userdata('status_login');
    if ($session!='oke') {
      redirect('Pages/login');
    }
  }

  function check_session_login()
  {
    $CI = & get_instance();
    $session = $CI->session->userdata('status_login');
    if ($session=='oke') {
      redirect('Dashboard');
    }
  }

  function check_session_login_user()
  {
    $CI = & get_instance();
    $session = $CI->session->userdata('status_login');
    if ($session=='oke') {
      redirect('Home');
    }
  }

 ?>
