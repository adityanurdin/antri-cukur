<!DOCTYPE html>
<?php
include_once("koneksi.php");
$result = mysqli_query($mysqli, "SELECT * FROM barokah ORDER BY id ASC");
$no_urut = 0;
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="author" content="Fajar Ramadhan">
    <meta name="description" content="Easy Haircut">

    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <link href="../metro/css/metro-all.css?ver=@@b-version" rel="stylesheet">
    <link href="../docsearch/docsearch.min.css" rel="stylesheet">
    <link href="../css/site.css" rel="stylesheet">

    <title>Easy Haircut</title>
</head>
<body>
<div class="container-fluid bg-darkGray fg-white pos-fixed fixed-top z-top">
    <header class="app-bar container bg-darkGray fg-white pos-relative app-bar-expand-md" data-role="appbar">
        <a href="/" class="brand fg-white no-hover">Easy Haircut</a>
        <ul class="app-bar-menu ml-auto">
            <li><a href="../about/index.html">About APP</a></li>
        </ul>
    </header>
</div>
    <div class="container-fluid">
	<h1>Barbershop 1</h1>
	<hr/>
	<button class="action-button second" onclick='location.reload();' value='Refresh Page' data-role="hint"
    data-hint-text="Refresh" data-hint-position="right">
    <span class="icon"><span class="mif-loop2"></span></span>
</button>
<div class="float-right bg-green rounded drop-shadow p-1 fg-white">Buka</div>
<hr/>
        <main class="cell-md-9 cell-xl-8 order-1 pr-1-sx pl-1-sx pr-5-md pl-5-md">
<table class="table striped example cell-border drop-shadow">
    <thead>
	<td>No</td>
	<td>Nama</td>
	<td>Status</td>
	</thead>
	<tbody>
	    <?php
		while($data = mysqli_fetch_array($result)) {
				$no_urut++;
			    echo "<tr>";
				echo "<td>$no_urut</td>";
				echo "<td>".$data['nama']."</td>";
				echo "<td>".$data['status']."</td>";
		}
		?>
	</table>
<div data-role="panel" data-title-caption="Jam Buka" data-collapsed="true" data-collapsible="true">
</div>
            </main>
        </div>

    </div>

    <script src="../docsearch/docsearch.min.js"></script>
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../metro/js/metro.js?ver=@@b-version"></script>
    <script src="../highlight/highlight.pack.js"></script>
    <script src="../js/clipboard.min.js"></script>
    <script src="../js/site.js"></script>
</body>
</html>
