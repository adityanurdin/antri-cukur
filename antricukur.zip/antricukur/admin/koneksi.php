<?php
$host = 'localhost';
$user = 'root';
$namadb = 'antricukur';
$pw = '';

$mysqli = mysqli_connect($host, $user, $pw, $namadb);
?>
