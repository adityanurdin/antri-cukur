<?php
date_default_timezone_set('Asia/Jakarta');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "antricukur";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$txtnama = $_POST['nama'];
$txtstatus = $_POST['status'];
$waktu = date("Y-m-d H:i:s");

$sql = "INSERT INTO barokah (nama,status,waktu)
VALUES ('$txtnama', '$txtstatus', '$waktu');";
$sql .= "INSERT INTO backupbarokah (nama,status,waktu)
VALUES ('$txtnama', '$txtstatus', '$waktu');";

if (mysqli_multi_query($conn, $sql)) {
   header('location:../admin/');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>
