<?php
   session_start();
   if(isset($_SESSION['username'])) {
   header('location:../admin/'); }
   require_once("koneksi.php");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <meta name="author" content="Muhammad Fajar Ramadhan">

    <link href="../metro/css/metro-all.css?ver=@@b-version" rel="stylesheet">

    <title>Login</title>

    <style>
        .login-form {
            width: 350px;
            height: auto;
            top: 50%;
            margin-top: -160px;
        }
    </style>
</head>
<body class="h-vh-100 bg-brandColor2">

    <form class="login-form bg-white p-6 mx-auto border bd-default win-shadow" action="loginuser" method="post">
        <span class="fg-darkBlue mif-notification mif-4x place-right" style="margin-top: -10px;"></span>
        <h2 class="text-light">Login Admin</h2>
        <hr class="thin mt-4 mb-4 bg-white">
        <div class="form-group">
            <input name="username" type="text" data-role="input" data-prepend="<span class='mif-lock'>" placeholder="Enter your ID...">
        </div>
        <div class="form-group">
            <input name="password" type="password" data-role="input" data-prepend="<span class='mif-key'>" placeholder="Enter your password...">
        </div>
        <div class="form-group mt-10">
            <button class="button">Login</button>
        </div>
    </form>

    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../metro/js/metro.js"></script>

</body>
</html>
