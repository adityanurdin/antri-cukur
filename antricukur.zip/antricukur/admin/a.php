<?php
// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id = $_POST['id'];
$status = $_POST['status'];

// update data ke database
mysqli_query($mysqli,"UPDATE status set status='$status' where id='$id'");

// mengalihkan halaman kembali ke index.php
header("location:../admin/");

?>
