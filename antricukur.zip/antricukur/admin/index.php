<?php
session_start();
include_once("koneksi.php");
if(!isset($_SESSION['username'])) {
   header('location:login/');
} else {
   $username = $_SESSION['username'];
}
$result = mysqli_query($mysqli, "SELECT * FROM user ORDER BY id DESC");
?>
<?php
include_once("koneksi.php");
$result = mysqli_query($mysqli, "SELECT * FROM barokah ORDER BY id ASC");
$edit = mysqli_query($mysqli,"SELECT * FROM status where id='1' ");
$ds = mysqli_query($mysqli,"SELECT * FROM status where id='1' ");
$no_urut = 0;
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="author" content="Fajar Ramadhan">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link href="../metro/css/metro-all.css?ver=@@b-version" rel="stylesheet">
    <link href="../highlight/styles/github.css" rel="stylesheet">
    <link href="../docsearch/docsearch.min.css" rel="stylesheet">
    <link href="../css/site.css" rel="stylesheet">

    <title>Easy Haircut</title>

</head>
<body>
  <div class="container-fluid bg-blue fg-white pos-fixed fixed-top z-top drop-shadow">
      <header class="app-bar container bg-blue fg-white pos-relative app-bar-expand-md" data-role="appbar">
          <a id="sidebar-toggle"><span class="mif-menu fg-white"></span></a>
          <b>&nbsp; AntriCukur</b>
      </header>
  </div>
  <!--  Demos -->
  <aside class="sidebar" data-role="sidebar" data-toggle="#sidebar-toggle" id="sb1">
  <div class="sidebar-header bg-darkBlue">
      <a href="/" class="fg-white sub-action" onclick="Metro.sidebar.close('#sb1'); return false;"><span class="mif-arrow-left mif-2x"></span></a>
      <div class="avatar">
          <img src="../images/logo.jpg">
      </div>
      <span class="title fg-white">AntriCukur</span>
      <span class="subtitle fg-white"> 2018 &copy; AntriCukur</span>
  </div>
  <ul class="sidebar-menu">
      <li><a href="/"><span class="mif-home fg-blue icon"></span>Home</a></li>
      <li><a href="../place"><span class="mif-shop fg-teal icon"></span>Place</a></li>
      <li class="divider"></li>
      <li><a><span class="mif-info fg-darkCyan icon"></span>About</a></li>
      <li><a><span class="mif-contacts-dialer fg-magenta icon"></span>contact us</a></li>
  </ul>
</aside>

    <div class="container-fluid">
        <div class="row flex-xl-nowrap">
            <main class="cell-md-9 cell-xl-8 order-1 pr-1-sx pl-1-sx pr-5-md pl-5-md">
                <div class="place-right d-none d-block-lg" style="width: 200px;">
                </div>
                <div class="example">
                <h4 align="center">Admin</h4>
                <hr/>
                <?php while($b = mysqli_fetch_array($ds)) { ?> <b><p class='text-center bg-lightBlue p-2 fg-white'> <?php echo $b['status'];?> </p></b> <?php } ?>
                <hr/>
                <?php while ($d = mysqli_fetch_array($edit)){
                  ?>
                <form action="a" method="post" name="form1">
                  <input type="hidden" name="id" value="<?php echo $d['id']; ?>">
                  <div class="d-flex flex-justify-center">
    <div><input type="radio" data-role="radio" value="Buka" name="status"/>Buka</div>
    <div><input type="radio" data-role="radio" value="Tutup" name="status"/>Tutup</div>
    <div class="ml-auto"><button class="button info fg-white" name="Submit">Update</button></div>
  </div>
                  <center></center>
                </form>
                <?php
  }
  ?>
                </div>
				<div data-role="panel" data-title-caption="Antrian" data-title-icon="<span class='mif-users'></span>" data-collapsed="false" data-collapsible="true">
          <button class="action-button second" onclick='location.reload();' value='Refresh Page' data-role="hint"
            data-hint-text="Refresh" data-hint-position="right">
            <span class="icon"><span class="mif-loop2"></span></span>
        </button>
				<table class="table striped table-border example row-border">
    <thead>
	<td>No</td>
	<td>Nama</td>
	<td>Status</td>
	<td>Action</td>
	</thead>
	<tbody>
	    <?php
		while($data = mysqli_fetch_array($result)) {
				$no_urut++;
			    echo "<tr>";
				echo "<td>$no_urut</td>";
				echo "<td>".$data['nama']."</td>";
				echo "<td>".$data['status']."</td>";
				echo "<td><a href='delete.php?id=$data[id]' class='button'><span class='mif-checkmark icon'></span></a></td></tr>";
		}
		?>
	</table>
	</div>

					<div class="example">
					<h4 align="center">Tambah Antrian</h4>
					<hr/>
					<form action="proses.php" method="post" name="form1">
						<input type="text" name="nama" data-role="input" data-prepend="Nama">
						<br/>
            <div class="d-flex flex-justify-center">
              <div><input type="radio" data-role="radio" value="Ditempat" name="status"/>Ditempat</div>
              <div><input type="radio" data-role="radio" value="Booking" name="status"/>Booking</div>
            </div>
						<br/>
            <center><button class="button bg-blue fg-white" name="Submit" >Tambah</button></center>
					</form>
					</div>
                <!-- ads-html -->
            </main>
        </div>

    </div>
    <div class="remark info">
    <center>
    <small>
      <cite class="Source Title"><code class="info">AntriCukur</code><br/>Check - Booking - Haircut</cite>
    </small>
  </center>
</div>
    <script src="../docsearch/docsearch.min.js"></script>
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../metro/js/metro.js?ver=@@b-version"></script>
    <script src="../highlight/highlight.pack.js"></script>
    <script src="../js/clipboard.min.js"></script>
    <script src="../js/site.js"></script>
    <!-- ads-script -->
    <!-- ga-script -->
    <!-- hit-ua -->
</body>
</html>
