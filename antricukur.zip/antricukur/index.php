<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <meta name="author" content="Fajar Ramadhan">
    <meta name="description" content="AntriCukur">

    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <link href="metro/css/metro-all.css?ver=@@b-version" rel="stylesheet">
    <link href="metro/css/metro.css" rel="stylesheet">
    <link href="highlight/styles/github.css" rel="stylesheet">
    <link href="docsearch/docsearch.min.css" rel="stylesheet">
    <link href="css/site.css" rel="stylesheet">
    <title>AntriCukur</title>
    <style>
        h4 {
            white-space: nowrap;
        }

        @media all and (min-width: 768px) {
            .hero {
                padding: 160px 80px 120px;
            }

            .neb-white {
                height: auto;
            }

        }

        [class*=cell-md-3] {
            display: flex;
            flex-flow: column;
            justify-content: flex-start;
        }

        [class*=cell-md-3] div:last-child {
            display: flex;
            justify-content: space-between;
            margin-top: auto!important;
        }

    </style>

</head>
<body style="padding-top: 50px">
  <div class="container-fluid bg-blue fg-white pos-fixed fixed-top z-top drop-shadow">
      <header class="app-bar container bg-blue fg-white pos-relative app-bar-expand-md" data-role="appbar">
          <a id="sidebar-toggle"><span class="mif-menu fg-white"></span></a>
          <b>&nbsp; AntriCukur</b>
      </header>
  </div>

  <!--  Demos -->
  <aside class="sidebar" data-role="sidebar" data-toggle="#sidebar-toggle" id="sb1">
  <div class="sidebar-header bg-darkBlue">
      <a href="/" class="fg-white sub-action" onclick="Metro.sidebar.close('#sb1'); return false;"><span class="mif-arrow-left mif-2x"></span></a>
      <div class="avatar">
          <img src="images/logo.jpg">
      </div>
      <span class="title fg-white">AntriCukur</span>
      <span class="subtitle fg-white"> 2018 &copy; AntriCukur</span>
  </div>
  <ul class="sidebar-menu">
      <li><a href="/"><span class="mif-home fg-blue icon"></span>Home</a></li>
      <li><a href="place/"><span class="mif-shop fg-teal icon"></span>Place</a></li>
      <li class="divider"></li>
      <li><a><span class="mif-info fg-darkCyan icon"></span>About</a></li>
      <li><a><span class="mif-contacts-dialer fg-magenta icon"></span>contact us</a></li>
  </ul>
</aside>

<div class="hero white-bg text-center neb neb-white bg-Gray">
    <h1 class="fg-darkBlue mt-10"><span class="reduce-1 enlarge-1-md">AntriCukur</span></h1>
    <div class="container mt-10 text-leader fg-blue pl-5-fs pr-5-fs pl-20-md pr-20-md">
        <p class="reduce-1 enlarge-1-md">
            Check - Booking - Haircut
        </p>
		<br/>
		        <a href="place/" class="command-button info rounded">
                    <span class="mif-shop icon fg-white"></span>
                    <span class="caption">
                        Check
                        <small>Check The Place</small>
                    </span>
                </a>
    </div>
</div>
<div class="container-fluid hero-bg pt-10 pb-20 neb neb-hero">
      <div class="container text-center">
          <div class="row mt-12">
              <div class="cell-md-4 mt-4">
                  <div><span class="mif-shop fg-white mif-5x ani-heartbeat"></span></div>
                  <h4 class="fg-white mt-4">Check</h4>
              </div>
              <div class="cell-md-4 mt-4">
                  <div><span class="mif-open-book mif-5x fg-white ani-heartbeat"></span></div>
                  <h4 class="fg-white mt-4">Booking</h4>
              </div>
              <div class="cell-md-4 mt-4">
                  <div><span class="mif-cut mif-5x fg-white ani-heartbeat"></span></div>
                  <h4 class="fg-white mt-4">Haircut</h4>
              </div>
          </div>

      </div>
  </div>
<footer class="footer-bg">
    <div class="container pt-10 pb-10">
        <div class="text-center">
            <ul class="inline-list reduce-1" id="social-menu">
                <li><a href="#"><span class="mif-facebook"></span></a></li>
                <li><a href="#"><span class="mif-instagram"></span></a></li>
            </ul>
        </div>
    </div>
</footer>
<script src="docsearch/docsearch.min.js"></script>
<script src="js/jquery-3.3.1.min.js"></script>
<script src="metro/js/metro.js?ver=@@b-version"></script>
<script src="highlight/highlight.pack.js"></script>
<script src="js/clipboard.min.js"></script>
<script src="js/site.js"></script>
</body>
</html>
