<!DOCTYPE html>
<?php
include_once("../admin/koneksi.php");
$antri = mysqli_query($mysqli, "SELECT * FROM barokah ORDER BY id ASC");
$stats = mysqli_query($mysqli, "SELECT * FROM status");
$no_urut = 0;
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="author" content="Fajar Ramadhan">
    <meta name="description" content="Easy Haircut">

    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <link href="../metro/css/metro-all.css?ver=@@b-version" rel="stylesheet">
    <link href="../docsearch/docsearch.min.css" rel="stylesheet">
    <link href="../css/site.css" rel="stylesheet">

    <title>Easy Haircut</title>
</head>
<body>
  <div class="container-fluid bg-blue fg-white pos-fixed fixed-top z-top drop-shadow">
      <header class="app-bar container bg-blue fg-white pos-relative app-bar-expand-md" data-role="appbar">
          <a id="sidebar-toggle"><span class="mif-menu fg-white"></span></a>
          <b>&nbsp; AntriCukur</b>
      </header>
  </div>
  <!--  Demos -->
  <aside class="sidebar" data-role="sidebar" data-toggle="#sidebar-toggle" id="sb1">
  <div class="sidebar-header bg-darkBlue">
      <a href="/" class="fg-white sub-action" onclick="Metro.sidebar.close('#sb1'); return false;"><span class="mif-arrow-left mif-2x"></span></a>
      <div class="avatar">
          <img src="../images/logo.jpg">
      </div>
      <span class="title fg-white">AntriCukur</span>
      <span class="subtitle fg-white"> 2018 &copy; AntriCukur</span>
  </div>
  <ul class="sidebar-menu">
      <li><a href="/"><span class="mif-home fg-blue icon"></span>Home</a></li>
      <li><a href="../place"><span class="mif-shop fg-teal icon"></span>Place</a></li>
      <li class="divider"></li>
      <li><a><span class="mif-info fg-darkCyan icon"></span>About</a></li>
      <li><a><span class="mif-contacts-dialer fg-magenta icon"></span>contact us</a></li>
  </ul>
</aside>
    <div class="container-fluid">
	<h1>Classic Cuts</h1>
	<hr/>
	<button class="action-button second" onclick='location.reload();' value='Refresh Page' data-role="hint"
    data-hint-text="Refresh" data-hint-position="right">
    <span class="icon"><span class="mif-loop2"></span></span>
</button>
<hr/>
<?php while($data = mysqli_fetch_array($stats)) { echo "<b><p class='text-center bg-lightBlue fg-white p-2'>".$data['status']."</p></b>";}?>
<hr/>
<ul class="tabs-expand-md" data-role="tabs">
                        <li><a href="#_List">List</a></li>
                        <li><a href="#_Gallery">Gallery</a></li>
                    </ul>
                    <div class="border bd-default no-border-top p-2">
                        <div id="_List">
                          <main class="cell-md-9 cell-xl-8 order-1 pr-1-sx pl-1-sx pr-5-md pl-5-md">
                          <table class="table striped table-border example row-border" data-role="table" data-show-search="true">
                          <thead>
                          <td>No</td>
                          <td>Nama</td>
                          <td>Status</td>
                          </thead>
                          <tbody>
                          <?php
                          while($data = mysqli_fetch_array($antri)) {
                          $no_urut++;
                            echo "<tr>";
                          echo "<td>$no_urut</td>";
                          echo "<td>".$data['nama']."</td>";
                          echo "<td>".$data['status']."</td>";
                          }
                          ?>
                          </table>
                          <hr/>
                          <div data-role="panel" data-title-caption="Booking (Beta)" data-collapsed="true" data-collapsible="true">
                            <form action="book" method="post" name="form1">
            <input type="text" name="nama" data-role="input" data-prepend="Nama">
            <br/>
            <select data-role="select" name="status" data-prepend="Status">
              <option class="fg-cyan">Booking</option>
            </select>
            <br/>
            <center><button class="button bg-gray fg-white" name="Submit">Booking</button></center>
          </form>
                          </div>
                              </main>
                        </div>

                        <div id="_Gallery">
                          <div class="example">
                    <div class="row mb-2">
                        <div class="cell-md-3">
                            <div class="img-container drop-shadow">
                                <img src="../images/CC/01.jpeg">
                            </div>
                        </div>
                        <hr/>
                        <div class="cell-md-3">
                            <div class="img-container drop-shadow">
                                <img src="../images/CC/02.jpeg">
                            </div>
                        </div>
                        <hr/>
                        <div class="cell-md-3">
                            <div class="img-container drop-shadow">
                                <img src="../images/CC/03.jpeg">
                            </div>
                        </div>
                        <div class="cell-md-3">
                            <div class="img-container drop-shadow">
                                <img src="../images/CC/04.jpeg">
                            </div>
                        </div>
                        <div class="cell-md-3">
                            <div class="img-container drop-shadow">
                                <img src="../images/CC/05.jpeg">
                            </div>
                        </div>
                        <div class="cell-md-3">
                            <div class="img-container drop-shadow">
                                <img src="../images/CC/06.jpeg">
                            </div>
                        </div>
                        <div class="cell-md-3">
                            <div class="img-container drop-shadow">
                                <img src="../images/CC/07.jpeg">
                            </div>
                        </div>
                    </div>
                </div>
                        </div>
                    </div>

        </div>

    </div>
    <div class="remark info">
    <center>
    <small>
      <cite class="Source Title"><code class="info">AntriCukur</code><br/>Check - Booking - Haircut</cite>
    </small>
  </center>
</div>
    <script src="../docsearch/docsearch.min.js"></script>
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../metro/js/metro.js?ver=@@b-version"></script>
    <script src="../highlight/highlight.pack.js"></script>
    <script src="../js/clipboard.min.js"></script>
    <script src="../js/site.js"></script>
</body>
</html>
