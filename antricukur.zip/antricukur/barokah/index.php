<!DOCTYPE html>
<?php
include_once("../admin/koneksi.php");
$result = mysqli_query($mysqli, "SELECT * FROM barokah ORDER BY id ASC");
$no_urut = 0;
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="author" content="Fajar Ramadhan">
    <meta name="description" content="Easy Haircut">

    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <link href="../metro/css/metro-all.css?ver=@@b-version" rel="stylesheet">
    <link href="../docsearch/docsearch.min.css" rel="stylesheet">
    <link href="../css/site.css" rel="stylesheet">

    <title>Easy Haircut</title>
		<script>
	var isCtrl = false;
document.onkeyup=function(e)
{
if(e.which == 17)
isCtrl=false;
}

document.onkeydown=function(e)
{
if(e.which == 17)
isCtrl=true;
if((e.which == 85) || (e.which == 67) && isCtrl == true)
{
//alert('Keyboard shortcuts are cool!');
return false;
}
}
</script>
<script type="text/javascript">
function disableselect(e){
return false
}

function reEnable(){
return true
}

//if IE4+
document.onselectstart=new Function ("return false")
document.oncontextmenu=new Function ("return false")
//if NS6
if (window.sidebar){
document.onmousedown=disableselect
document.onclick=reEnable
}
</script>
</head>
<body>
  <div class="container-fluid bg-blue fg-white pos-fixed fixed-top z-top drop-shadow">
      <header class="app-bar container bg-blue fg-white pos-relative app-bar-expand-md" data-role="appbar">
          <a id="sidebar-toggle"><span class="mif-menu fg-white"></span></a>
      </header>
  </div>
  <!--  Demos -->
  <aside class="sidebar" data-role="sidebar" data-toggle="#sidebar-toggle" id="sb1">
  <div class="sidebar-header bg-darkBlue">
      <a href="/" class="fg-white sub-action" onclick="Metro.sidebar.close('#sb1'); return false;"><span class="mif-arrow-left mif-2x"></span></a>
      <div class="avatar">
          <img src="">
      </div>
      <span class="title fg-white">AntriCukur</span>
      <span class="subtitle fg-white"> 2018 &copy; AntriCukur</span>
  </div>
  <ul class="sidebar-menu">
      <li><a href="/"><span class="mif-home icon"></span>Home</a></li>
      <li><a href="place/"><span class="mif-shop icon"></span>Place</a></li>
      <li class="divider"></li>
      <li><a><span class="mif-info icon"></span>About</a></li>
      <li><a><span class="mif-contacts-dialer icon"></span>contact us</a></li>
  </ul>
</aside>
    <div class="container-fluid">
	<h1>Barbershop 1</h1>
	<hr/>
	<button class="action-button second" onclick='location.reload();' value='Refresh Page' data-role="hint"
    data-hint-text="Refresh" data-hint-position="right">
    <span class="icon"><span class="mif-loop2"></span></span>
</button>
<div class="float-right bg-green rounded drop-shadow p-1 fg-white">Buka</div>
<hr/>
        <main class="cell-md-9 cell-xl-8 order-1 pr-1-sx pl-1-sx pr-5-md pl-5-md">
<table class="table striped example cell-border drop-shadow" data-role="table" data-show-search="true">
    <thead>
	<td>No</td>
	<td>Nama</td>
	<td>Status</td>
	</thead>
	<tbody>
	    <?php
		while($data = mysqli_fetch_array($result)) {
				$no_urut++;
			    echo "<tr>";
				echo "<td>$no_urut</td>";
				echo "<td>".$data['nama']."</td>";
				echo "<td>".$data['status']."</td>";
		}
		?>
	</table>
<div data-role="panel" data-title-caption="Jam Buka" data-collapsed="true" data-collapsible="true">
  <form action="proses.php" method="post" name="form1">
            <input type="text" name="nama" data-role="input" data-prepend="Nama">
            <br/>
            <select data-role="select" name="status" data-prepend="Status">
              <option class="fg-cyan">Ditempat</option>
              <option class="fg-cyan">Booking</option>
            </select>
            <br/>
            <input type="Text" data-role="calendarpicker" name="tanggal" data-prepend="Tanggal" value="<?php echo date('Y/m/d') ?>">
            <input data-role="timepicker" name="jam" data-seconds="false">
            <center><button class="button bg-darkGray fg-white rounded" name="Submit" >Tambah</button></center>
          </form>
</div>
            </main>
        </div>

    </div>

    <script src="../docsearch/docsearch.min.js"></script>
    <script src="../js/jquery-3.3.1.min.js"></script>
    <script src="../metro/js/metro.js?ver=@@b-version"></script>
    <script src="../highlight/highlight.pack.js"></script>
    <script src="../js/clipboard.min.js"></script>
    <script src="../js/site.js"></script>
</body>
</html>
