<?php
include '../admin/koneksi.php';
?>
<table class="data">
	<tr>
		<th>Nama</th>
		<th>Status</th>
	</tr>
	<?php
	$data = mysql_query("SELECT * FROM barokah");
	while($d=mysql_fetch_array($data)){
	?>
	<tr>
		<td><?php echo $d['nama'] ?></td>
		<td><?php echo $d['status'] ?></td>
	</tr>
	<?php } ?>
</table>
