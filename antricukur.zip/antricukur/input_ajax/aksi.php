<?php
include '../admin/koneksi.php';
$nama = $_POST['nama'];
$status = $_POST['status'];

mysql_query("insert into user values('','$nama','$status')");
?>
